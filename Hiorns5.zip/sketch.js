let bg1 = 101;
let bg2 = 76;
let bg3 = 79;
var rad = 50;
var rad2 = 40;
var b1 = 685;
var b2 = 150;
var c1 = 55;
var c2 = 150;
var x = 25;
var y = 300;
var w = 80;
var h = 150;
let bool = false;
let bool2 = false;

function setup() {
  createCanvas(750, 600);
  colorMode(RGB,255,255,255,1);
  ellipseMode(RADIUS);
}

function draw() {
  background(bg1,bg2,bg3);
  noStroke();
  fill(178, 110, 99);
  rect(0,0,130,600);
  rect(0,0,750,80);
  rect(620,0,130,600);
  rect(0,520,750,80);
  
  stroke(101,76,79);
  strokeWeight(5);
  fill(157,169,160);
  ellipse(b1,b2,rad);
  stroke(101,76,79);
  strokeWeight(5);
  fill(206,192,117);
  ellipse(c1,c2,rad2);
  textSize(32);
  text('"x"',36,150);
  textSize(10);
  text('o  f  f',42.5,167);
  textSize(28);
  text('"click"',650,150);
  textSize(10);
  text('o  n',677,167);
  
  
  fill(192,252,173);
  rect(x, y, w, h);
  textSize(25);
  text('"click"',32.5,340);
  textSize(10);
  text('c h a n n e l',40,370);
  
  if (bool2 == true){
      noStroke();
      fill(101,76,79);
      textSize(60);
      text('Hello World',220,300);
      textSize(15);
    stroke(101,76,79);
    strokeWeight(2);
    fill(192,202,173);
    text('CHANNEL 2',145,110);
  }else if (bool == true){
            textSize(15);
    stroke(101,76,79);
    strokeWeight(2);
    fill(206,192,117);
    text('CHANNEL 1',145,110);
    noFill();
    stroke(101,76,79);
    strokeWeight(5);
    ellipse(375,300,40);
    line(375,340,375,400);
    line(350,355,400,355);
    line(375,400,350,440);
    line(375,400,400,440);
    point(375,280);
    point(390,290);
    arc(375, 300, 20, 20, 0.4, PI + QUARTER_PI, OPEN);
            }
  
  var d = dist(mouseX, mouseY, b1, b2);
  var e = dist(mouseX, mouseY, c1, c2);x
  
  if (mouseIsPressed) {

				
				if (d < rad) {
					
					bg1 = 192;
                    bg2 = 202;
                    bg3 = 173;
                    bool = true;
                  bool2 = false;
                  print(bool);
				}else bool = false;
    print(bool);
				

  }else if (keyIsPressed) {
		
		if (key == 'x') {
				
				if (e < rad2) {
					
				  bg1 = 101;
                  bg2 = 76;
                  bg3 = 79;
                  bool = false;
                  bool2 = false;
                  print(bool);

	  }
    }			  
  }
  
}

function mousePressed() {

	background (204);

	if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
      if (bool == true){
      bg1 = 206;
      bg2 = 192;
      bg3 = 117;
        bool2 = true;
        print(bool2);
  
      }else bool2 = false; print(bool2);
  }
  
}





