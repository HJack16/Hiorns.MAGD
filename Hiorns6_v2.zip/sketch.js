var num = 60;
var x = [];
var y = [];


function setup() {
    createCanvas(500, 500);
    noStroke();
    for (var i = 0; i < num; i++) {
        x[i] = 0;
        y[i] = 0;
    }
}

function draw() {
    background(74, 49, 77);
  
  fill(107, 101, 112,80);
  ellipse(50,80,150,80);
  ellipse(70,85,200,80);
  ellipse(30,95,180,80);
  ellipse(450,80,150,80);
  ellipse(470,85,200,80);
  ellipse(430,95,180,80);
  
  
  fill(168, 186, 154);
  rect(210,400,80,100);
  ellipse(250,400,80)
  
  fill(26, 9, 13);
  noStroke();
  triangle(0,500,50,50,20,500);
  triangle(18,250,50,50,20,500);
  triangle(18,250,150,50,20,300);
  triangle(400,500,450,50,420,500);
  triangle(418,250,450,50,420,500);
  triangle(418,250,350,50,420,300);
  
  ellipse(250,680,80,80);
  
  fill(26, 9, 13);
  textSize(28);
  textFont('Georgia');
  text("R.I.P.",215,430);
  textSize(15);
  textFont('Georgia');
  text("Earl",235,455);
    
    // Copy array values from back to front
    for (var i = num - 1; i > 0; i--) {
        x[i] = x[i - 1];
        y[i] = y[i - 1];
    }
    
    x[0] = mouseX; // Set the first element
    y[0] = mouseY; // Set the first element
    
    // Draw a cartoon ghost following the mouse with varying fill color
    for (var i = 0; i < num; i++) {
        fill(i * 4,252,172,20);
        noStroke();
        ellipse(x[i], y[i], 80, 90);
    ellipse(x[i] - 20, y[i] + 35, 20, 30);
    ellipse(x[i], y[i] + 35, 20, 30);
    ellipse(x[i] + 20, y[i] + 35, 20, 30);
    }
    
    // Ghost eyes
    fill(26, 9, 13,95);
    ellipse(mouseX - 10, mouseY - 10, 10, 25);
    ellipse(mouseX + 10, mouseY - 10, 10, 25);
    
    // Ghost mouth
    ellipse(mouseX, mouseY + 10, 10, 20);
    
  print(x);
}